# Expected outputs and acceptance

| Artifact | Minimum content | PASS condition |
|---|---|---|
| `PILOT_CONTRACT.md` | owner, process, labels, error cost, data, budget, STOP, rollback | Signed/approved by owner |
| `questions.json` | pinned model, versioned questions/criteria | Schema + peer review |
| `eval_tune.jsonl` | human labels, provenance | No synthetic ground truth |
| `eval_holdout.jsonl` | frozen IDs/labels | Hash recorded before tuning |
| dry-run receipt | config/dataset hashes, payload hashes, cost/call guard | No network/key |
| baseline report | same holdout across alternatives | Per-class metrics |
| Jev eval report | answers, model version, usage, latency | Critical gates met |
| shadow report | disagreement, incidents, coverage/escalation | No side effects |
| go/no-go record | STOP/REDESIGN/CANARY REQUEST + open risks | Owner decision |
| rollback receipt | flag state, traffic share, fallback health | Readback proves safe state |

## Never label as PASS

- one attractive example;
- average accuracy without critical-class recall/FN;
- vendor benchmark copied as your result;
- dry run presented as live integration;
- synthetic sample presented as product quality;
- local file existence presented as production rollback;
- agent completion without owner decision/readback.