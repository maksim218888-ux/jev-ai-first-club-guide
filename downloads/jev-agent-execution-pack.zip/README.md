# Jev bounded pilot/eval harness

Безопасный набор для проверки Jev как узкого decision layer. Он не превращает coding agent в Jev-агента и не даёт модели права выполнять действия: Jev возвращает typed answers, обычный код маршрутизирует их, а рискованный хвост остаётся сильной модели или человеку.

## Результат пилота

На выходе должны появиться:

1. `PILOT_CONTRACT.md` — процесс, owner, цена ошибок, бюджет, данные, STOP и rollback.
2. Версионированные questions и routing rules.
3. Human-labelled tune set и frozen holdout.
4. Dry-run receipt с SHA-256 конфигурации/датасета и оценкой верхней границы вызовов.
5. Baseline/eval report: confusion matrix, precision/recall критичных классов, coverage, escalation, p50/p95, полный cost.
6. Shadow report и подписанное решение `STOP / REDESIGN / CANARY REQUEST`.
7. Rollback readback. Pack сам canary/production не включает.

## Быстрый безопасный старт

```bash
cp config.example.json config.local.json
python3 scripts/jev_pilot.py \
  --config config.local.json \
  --dataset examples/sample_eval.jsonl \
  --dry-run
python3 -m unittest discover -s tests -v
```

Sample data — synthetic smoke test. Она доказывает только работоспособность локального контура, не качество Jev.

Harness исполняет локальные safety/eval-механизмы: object allow-list, recursive scan вложенных полей и PII/secrets внутри текста, hard network-attempt/token/budget caps, hash-bound approval, exact response-schema validation, per-question thresholds и companion Noul gate. `max_test_calls` считает все внешние попытки, включая разрешённые retry после 429/529; timeout и 5xx автоматически не повторяются. Он не создаёт production/shadow-инфраструктуру и не выполняет side effects.

## Live test — только после STOP

1. Владелец создаёт аккаунт/ключ сам и хранит ключ в secret manager или env.
2. Владелец проверяет legal/data/payment settings, при необходимости запрашивает ZDR.
3. Dry run выдаёт hashes. Владелец копирует их в `approval.local.json`, задаёт точное число вызовов и срок.
4. Только затем:

```bash
export TYPESAFE_API_KEY='set outside project and shell history where possible'
python3 scripts/jev_pilot.py \
  --config config.local.json \
  --dataset eval.deidentified.jsonl \
  --live --approval approval.local.json \
  --output jev-live-results.redacted.json
```

## Что pack сознательно не делает

- не устанавливает `typesafe-sdk` или внешний agent skill;
- не регистрирует аккаунт, не создаёт и не читает ключ;
- не покупает credits и не включает auto-reload;
- не отправляет sensitive/regulated data;
- не включает images, Box или long-context;
- не меняет CI, облако, права или production;
- не публикует и не совершает side effects.

## Текущая официальная база (18.11.2026)

- endpoint `POST https://api.typesafe.ai/v1/systemone`;
- pinned stable model `jev-1.14.0`; floating aliases harness не принимает;
- цена `$0.042 / 1M input tokens`; output tokens не тарифицируются;
- default context: 64k per request / 32k per question;
- long context 262k требует danger-zone header и отдельного пилота;
- запрос до 32 MiB; SDK автоматически обрабатывает 429/529 retry policy;
- ZDR доступен по запросу и подтверждается в console settings.

См. `SOURCES.md`, `STOP_CONDITIONS.md` и `ROLLBACK_RUNBOOK.md`.

## Честная граница

Pack доказывает локальную готовность и ограниченный eval-контур. Он не создаёт аккаунт, ключ, оплату, feature flag, shadow pipeline или production-интеграцию. Live test разрешается только отдельным owner approval-файлом, связанным с точными SHA-256, моделью, endpoint, числом вызовов, сроком и классом данных.