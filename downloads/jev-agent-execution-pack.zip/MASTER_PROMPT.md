# MASTER PROMPT — safe Jev pilot

Ты работаешь только в пределах этого pack. Цель — подготовить доказуемый низкорисковый пилот Jev, не выполняя owner-only, paid, credential, destructive, production или public actions.

## Порядок

1. Прочитай `OWNER_INPUTS.md`, `STOP_CONDITIONS.md`, `DECISION_RULES.md`, `SECURITY_PRIVACY.md`, `ROLLBACK_RUNBOOK.md` и `QA_CHECKLIST.md`.
2. Исследуй локальную среду и проект read-only. Не устанавливай package/skill и не запускай сеть.
3. Проверь наличие owner contract, human labels, baseline, tune/frozen holdout, privacy allow-list, бюджета, fallback и rollback owner. При пробеле — STOP.
4. Предложи 2–3 декомпозиции Choice/Score/Noul. Объясни, какое действие остаётся в обычном коде. Не синтезируй ground truth.
5. Для неполного Choice предложи companion Noul; не полагайся автоматически на `other`.
6. Закрепи `jev-1.14.0` для eval. Alias `jev-latest` допустим только в exploration и требует повторной калибровки при смене версии.
7. Создай/измени только локальные файлы, тесты, dry run, eval-шаблон, shadow plan и rollback plan.
8. Запусти dry run и тесты. Покажи hashes, число вызовов, conservative token/cost guard, endpoint, model и поля, которые уйдут наружу.
9. Остановись. Live разрешён только отдельным owner approval-файлом, связанным с exact config/dataset hashes и сроком.
10. После разрешённого live test сохрани только обезличенные IDs, model version, typed answers, routes, usage и агрегированные метрики. Не логируй ключ или полный payload.
11. При timeout/5xx/неясном сетевом исходе не повторяй вызов автоматически. При 401/402/403/413/415/422 — STOP. При 429/529 — bounded retry только внутри owner-approved hard network-attempt cap.
12. Shadow mode не совершает side effects. Canary/production — новый owner-only этап вне этого pack.

## Обязательный итог

- созданные/изменённые файлы;
- команды и фактические результаты;
- hashes и версии;
- eval/shadow метрики либо честное `not run`;
- открытые риски;
- следующий exact owner decision;
- доказательство, что account/key/payment/production/public actions не выполнялись.