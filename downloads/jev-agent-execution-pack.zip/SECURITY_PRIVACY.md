# Security, privacy and legal boundary

## Default

Отправляйте минимальный state. Allow-list сильнее blacklist: неизвестное поле блокируется. Recursive scan — лишь дополнительная защита, а не замена data mapping и правового review.

Запрещено помещать в config, dataset, ZIP, Git, prompt или log:

- API keys, auth headers, passwords, cookies, tokens;
- лишние имена, email, телефоны, адреса и идентификаторы;
- платёжные реквизиты, PHI/medical, credentials, клиентские secrets;
- полный production payload, если метрики можно посчитать по ID/label/answer.

## Что подтверждают официальные материалы

TypeSafe пишет, что Jev не обучается на customer requests/responses. Данные всё равно могут обрабатываться для сервиса, usage, abuse prevention и telemetry. ZDR доступен по запросу: организация отправляет support request, после включения статус виден в `Settings → Organization`. Для PHI официальный help center требует включённый ZDR и подписанный BAA до отправки PHI. DPA включает EU SCC и UK Addendum; отдельную data-residency опцию нельзя предполагать без подтверждения.

## Практическое решение

- Первый пилот: deidentified low-risk text.
- ZDR, DPA/BAA/SCC, subprocessors, residency и retention проверяет владелец/legal/security.
- При неизвестной категории данных — STOP, а не «скорее всего можно».
- Ambiguous timeout нельзя автоматически повторять: запрос мог быть обработан.
- Logs: request ID/hash, model version, answer, route, usage, latency, error class. Не полный state и не key.

Harness принимает только object-shaped state с явным allow-list верхнего уровня. Он fail-closed блокирует вложенные sensitive keys, email, телефон, SSN, номера карт, IP-адреса и похожие секреты внутри строк. Это защитный фильтр, а не обещание найти любой вид PII: владелец отдельно утверждает обезличенный файл и diff.

## API-key governance

По текущей официальной справке TypeSafe все участники организации могут видеть все API-ключи; developers управляют только созданными ими ключами, admins — всеми ключами организации. У ключей нет срока действия, плановой ротации и per-key spend limit. До live test владелец обязан:

1. сократить membership до минимально необходимого и проверить, кто видит ключи;
2. использовать отдельную тестовую организацию/проект, если это доступно;
3. создать отдельный test key вне pack и не передавать его агенту;
4. включить доступные usage alerts и вручную контролировать общий расход;
5. после теста сразу отозвать test key и проверить отказ следующего запроса;
6. записать дату создания, владельца, дату обязательной ротации и факт revoke без значения ключа.

## Incident

При подозрении на утечку: выключить feature flag, остановить вызовы, ротировать ключ owner-only процедурой, сохранить минимальные forensic metadata, уведомить security/legal и не возобновлять работу до signed go/no-go.