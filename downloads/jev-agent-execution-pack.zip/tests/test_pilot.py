import importlib.util
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).parents[1]
SCRIPT = ROOT / "scripts" / "jev_pilot.py"
SPEC = importlib.util.spec_from_file_location("jev_pilot", SCRIPT)
MOD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MOD)


class JevPilotTests(unittest.TestCase):
    def test_example_config_valid(self):
        cfg = json.loads((ROOT / "config.example.json").read_text(encoding="utf-8"))
        self.assertEqual(MOD.validate_config(cfg), [])

    def test_recursive_forbidden_field_stops(self):
        findings = MOD.scan_state(
            {"text": "hello", "nested": {"token": "not-allowed"}},
            {"text", "nested"},
            {"token"},
        )
        self.assertTrue(any("token" in item for item in findings))

    def test_unknown_top_level_field_stops(self):
        findings = MOD.scan_state({"text": "ok", "customer_id": "123"}, {"text"}, set())
        self.assertTrue(any("not allow-listed" in item for item in findings))

    def test_secret_value_stops(self):
        findings = MOD.scan_state({"text": "Bearer abcdefghijklmnop"}, {"text"}, set())
        self.assertTrue(any("possible secret" in item for item in findings))

    def test_email_and_phone_inside_text_stop(self):
        for text in ("Contact alice@example.com", "Call +1 (415) 555-0100"):
            findings = MOD.scan_state({"text": text}, {"text"}, set())
            self.assertTrue(any("possible secret or regulated identifier" in item for item in findings), text)

    def test_non_object_state_stops(self):
        self.assertTrue(MOD.scan_state("free-form email alice@example.com", {"text"}, set()))

    def test_dry_run_has_no_authorization_or_key(self):
        proc = subprocess.run(
            [
                "python3", str(SCRIPT),
                "--config", str(ROOT / "config.example.json"),
                "--dataset", str(ROOT / "examples" / "sample_eval.jsonl"),
                "--dry-run",
            ],
            capture_output=True,
            text=True,
        )
        self.assertEqual(proc.returncode, 0, proc.stderr)
        doc = json.loads(proc.stdout)
        self.assertTrue(doc["ok"])
        self.assertEqual(doc["selected_calls"], 3)
        self.assertNotIn("Authorization", proc.stdout)
        self.assertNotIn("TYPESAFE_API_KEY", proc.stdout)

    def test_live_without_approval_stops_before_key_or_network(self):
        proc = subprocess.run(
            [
                "python3", str(SCRIPT),
                "--config", str(ROOT / "config.example.json"),
                "--dataset", str(ROOT / "examples" / "sample_eval.jsonl"),
                "--live",
            ],
            capture_output=True,
            text=True,
        )
        self.assertEqual(proc.returncode, 2)
        self.assertIn("requires --approval", proc.stderr)

    def test_approval_hash_mismatch_stops(self):
        cfg = json.loads((ROOT / "config.example.json").read_text(encoding="utf-8"))
        rows = MOD.load_jsonl(ROOT / "examples" / "sample_eval.jsonl")
        approval = {
            "approval_phrase": MOD.LIVE_PHRASE,
            "config_sha256": "wrong",
            "dataset_sha256": "wrong",
            "endpoint": MOD.ENDPOINT,
            "model": cfg["model"],
            "approved_calls": len(rows),
            "data_class": "deidentified-low-risk",
            "expires_at_utc": "2099-01-01T00:00:00Z",
            "allow_sensitive_data": False,
            "allow_production": False,
        }
        with self.assertRaises(MOD.StopError):
            MOD.verify_approval(approval, cfg, rows, "expected-config", "expected-data")

    def test_route_unknown_schema_fails_closed(self):
        cfg = json.loads((ROOT / "config.example.json").read_text(encoding="utf-8"))
        self.assertEqual(MOD.route_answer({"type": "mystery"}, cfg["routing"]), "human")

    def test_companion_noul_blocks_primary_auto_route(self):
        cfg = json.loads((ROOT / "config.example.json").read_text(encoding="utf-8"))
        response = {
            "model": "jev-1.14.0",
            "answers": {
                "route": {"type": "choice", "choice": "product_help", "probabilities": {"product_help": 0.98}},
                "route_is_covered": {"type": "noul", "probability": 0.55},
            },
        }
        routed = MOD.validate_and_route_response(response, cfg)
        self.assertEqual(routed["routes"]["route"], "auto-candidate")
        self.assertEqual(routed["final_route"], "human")

    def test_response_model_mismatch_stops(self):
        cfg = json.loads((ROOT / "config.example.json").read_text(encoding="utf-8"))
        with self.assertRaises(MOD.StopError):
            MOD.validate_and_route_response({"model": "jev-latest", "answers": {}}, cfg)

    def test_budget_preflight_stops(self):
        cfg = json.loads((ROOT / "config.example.json").read_text(encoding="utf-8"))
        cfg["max_budget_usd"] = 0
        with tempfile.TemporaryDirectory() as td:
            config_path = Path(td) / "config.json"
            config_path.write_text(json.dumps(cfg), encoding="utf-8")
            proc = subprocess.run([
                "python3", str(SCRIPT), "--config", str(config_path),
                "--dataset", str(ROOT / "examples" / "sample_eval.jsonl"), "--dry-run"
            ], capture_output=True, text=True)
            self.assertEqual(proc.returncode, 2)
            self.assertIn("exceeds budget", proc.stderr)

    def test_dry_run_call_cap_stops_before_network(self):
        cfg = json.loads((ROOT / "config.example.json").read_text(encoding="utf-8"))
        cfg["max_test_calls"] = 2
        with tempfile.TemporaryDirectory() as td:
            config_path = Path(td) / "config.json"
            config_path.write_text(json.dumps(cfg), encoding="utf-8")
            proc = subprocess.run([
                "python3", str(SCRIPT), "--config", str(config_path),
                "--dataset", str(ROOT / "examples" / "sample_eval.jsonl"), "--dry-run"
            ], capture_output=True, text=True)
            self.assertEqual(proc.returncode, 2)
            self.assertIn("exceed hard max_test_calls", proc.stderr)

    def test_approval_call_cap_binds_config(self):
        cfg = json.loads((ROOT / "config.example.json").read_text(encoding="utf-8"))
        rows = MOD.load_jsonl(ROOT / "examples" / "sample_eval.jsonl")
        approval = {
            "approval_phrase": MOD.LIVE_PHRASE,
            "config_sha256": "config",
            "dataset_sha256": "dataset",
            "endpoint": MOD.ENDPOINT,
            "model": cfg["model"],
            "approved_calls": cfg["max_test_calls"] - 1,
            "data_class": "deidentified-low-risk",
            "expires_at_utc": "2099-01-01T00:00:00Z",
            "allow_sensitive_data": False,
            "allow_production": False,
        }
        with self.assertRaisesRegex(MOD.StopError, "hard network-attempt cap"):
            MOD.verify_approval(approval, cfg, rows, "config", "dataset")


if __name__ == "__main__":
    unittest.main()
