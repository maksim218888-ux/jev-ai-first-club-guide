# Troubleshooting and failure recovery

| Симптом | Безопасное действие |
|---|---|
| 400 / `max_tokens_exceeded` | Проверить JSON, finite numbers, nesting и context; не включать long-context без отдельного approval/eval. |
| 401 | STOP. Не печатать ключ; владелец проверяет env/credential scope. |
| 402 / balance/payment issue | STOP. Не покупать credits и не включать auto-reload. |
| 403 | STOP. Проверить права/договорный доступ владельцем. |
| 413 | Сократить payload; лимит body 32 MiB применяется до и после compression. |
| 415 | Убрать неподдерживаемую/двойную compression. |
| 422 | Исправить request schema/questions локально; не retry тем же payload. |
| 429 / 529 | Harness делает bounded backoff только в пределах `max_test_calls`; каждая попытка расходует hard network-attempt cap. После лимита — fallback. |
| 5xx | Harness не повторяет автоматически: paid outcome может быть неоднозначен. Только owner review/readback, затем новый scoped approval. |
| Timeout / connection reset | Исход неоднозначен: не повторять автоматически, проверить usage/readback. |
| Unknown response/model | STOP, сохранить обезличенный receipt, не маршрутизировать действие. |
| Choice всегда «что-то» выбирает | Добавить companion Noul; `other` использовать только после eval. |
| Низкая точность | Сузить judgment, разделить признаки, улучшить criteria, проверить labels/leakage. |
| Высокая уверенность, плохое качество | Confidence не равно доказанной correctness; перекалибровать на holdout. |
| Drift | Поднять escalation до 100%, выключить auto-candidate, собрать новый labelled slice. |
| Cost выше ожиданий | Остановить новые calls; считать fallback/human/engineering, а не только Jev API. |
| SDK/alias изменился | Сверить official docs/changelog, pin version, повторить eval до rollout. |

Recovery заканчивается не «ошибка исчезла», а readback: прежний маршрут работает, Jev traffic 0% или утверждённый bounded %, метрики стабильны, incident owner закрыл решение.