# Decision rules

## 1. Выбор primitive

- **Choice**: конечный неупорядоченный набор. Choice всегда выбирает один вариант. Если множество может быть неполным, `other/none` допустим, но официальный guide предупреждает, что такой вариант часто слаб; предпочтительнее companion Noul.
- **Score**: упорядоченные уровни с конкретным смыслом каждого уровня.
- **Noul**: вероятность истинности одного yes/no утверждения; отдельного `confidence` у Noul нет.
- **Box/images**: только отдельный multimodal pilot; не включать в первый текстовый пилот.

## 2. Что threshold-ить

- Noul: саму probability; промежуточный диапазон не округлять молча.
- Choice: probability выбранного действия; `confidence` показывает концентрацию распределения, а не независимую вероятность правильности.
- Score: probability нужного уровня и, при необходимости, confidence распределения.
- Любые пороги — стартовая гипотеза, проверяемая на holdout по цене FP/FN.
- Порог задаётся отдельно для каждого question ID и версии question. Один универсальный threshold для разных вопросов запрещён.
- Независимый benchmark Jev 1.13 обнаружил неравномерную калибровку: Choice был в среднем полезнее откалиброван, single Noul местами under-confident, а multi-label Noul мог заметно переоценивать `yes`. Probability/confidence применяются только после tune + frozen holdout и selective-routing проверки.

## 3. Маршрутизация

1. Schema/API/error/OOD/drift/high risk → human/fallback.
2. Companion Noul ниже owner-порога → human/fallback, Choice игнорируется.
3. Низкий риск + нужная probability выше auto threshold + holdout/shadow gates PASS → только auto-candidate.
4. Средняя зона → stronger model или человек.
5. Реальное действие выполняет обычный код после отдельной проверки; Jev не получает полномочий на side effect.

## 4. Версионирование

Для воспроизводимого eval закрепляйте `jev-1.14.0`. `jev-latest` движется при новом релизе, поэтому требует повторной калибровки до смены pinned version.