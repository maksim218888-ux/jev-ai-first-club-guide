# Alternatives and selection matrix

Сравнивайте на одном frozen holdout, с одинаковыми error costs и latency/cost boundaries.

| Вариант | Когда сильнее | Главный риск |
|---|---|---|
| Rules/regex | Границы точны и стабильны; аудит важнее гибкости | Хрупкость на вариативном языке |
| Классический classifier | Большой стабильный labelled set | Обслуживание features/drift |
| Embeddings + kNN/reranker | Similarity/retrieval/routing | Порог близости не равен бизнес-решению |
| Локальная малая модель | Нужен data control/offline | Инфраструктура, eval, latency |
| Frontier LLM structured output | Нужна широкая генерация/рассуждение | Цена, latency, non-determinism |
| Jev | Много узких typed judgments и probability-aware routing | Узкий fit, vendor/API dependency |
| Human | Высокая цена ошибки/редкие случаи | Cost, queue, consistency |
| Hybrid cascade | Разные слои задач и рисков | Сложнее monitoring/rollback |

## Weighted decision

Владелец задаёт веса: critical quality, safe coverage, latency p95, total cost, privacy/residency, implementation effort, observability, vendor lock-in, rollback simplicity. Агент не выбирает веса сам.

Jev проходит только если выигрывает нужный baseline на ваших данных. Ничья — нормальный результат; простое правило или человек часто лучше первого пилота.