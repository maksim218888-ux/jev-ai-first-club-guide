# Economics

## API price

На 18.11.2026 official Models page указывает `$0.042` за 1 million input tokens для Jev 1.14/1.13; output tokens не тарифицируются.

`jev_api_cost = actual_input_tokens / 1_000_000 × 0.042`

Предварительная оценка runner — conservative guard по размеру JSON, а не vendor tokenizer. После live test используйте `usage.input_tokens`.

## Total cost of ownership

`TCO = Jev API + fallback model + human review + engineering + monitoring + data/legal/security + incidents/error cost`

Считайте минимум три сценария:

- best: высокая safe coverage, низкая escalation;
- base: фактические holdout/shadow значения;
- worst: drift/ошибки, 100% fallback и incident overhead.

## Decision metrics

- cost per processed item;
- cost per correct low-risk auto-candidate;
- manual minutes saved after subtracting reviews/incidents;
- error cost by class;
- break-even volume;
- sensitivity to escalation rate and pinned-model change.

Низкая цена API не является go-live критерием. Если critical recall/FN, privacy, fallback или rollback не проходят, дешёвый вызов не делает систему выгодной.