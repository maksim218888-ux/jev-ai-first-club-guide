#!/usr/bin/env python3
"""Evaluate a redacted Jev result file against labelled JSONL.

Supports Choice labels and reports per-class precision/recall, confusion matrix,
coverage and escalation. It does not infer or synthesize labels.
"""
from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path


def load_jsonl(path: Path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def safe_div(a, b):
    return a / b if b else 0.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True, type=Path)
    ap.add_argument("--results", required=True, type=Path)
    ap.add_argument("--question", required=True)
    ap.add_argument("--output", type=Path)
    args = ap.parse_args()

    labels = {row["id"]: row.get("expected", {}).get(args.question) for row in load_jsonl(args.dataset)}
    result_doc = json.loads(args.results.read_text(encoding="utf-8"))
    rows = result_doc.get("results") or []
    confusion = defaultdict(Counter)
    routed = Counter()
    evaluated = 0
    missing = []

    for row in rows:
        rid = row.get("id")
        expected = labels.get(rid)
        answer = (row.get("answers") or {}).get(args.question) or {}
        predicted = answer.get("choice")
        route = (row.get("routes") or {}).get(args.question, "human")
        routed[route] += 1
        if expected is None or predicted is None:
            missing.append(rid)
            continue
        confusion[str(expected)][str(predicted)] += 1
        evaluated += 1

    classes = sorted(set(confusion) | {p for counts in confusion.values() for p in counts})
    metrics = {}
    for cls in classes:
        tp = confusion[cls][cls]
        fp = sum(confusion[actual][cls] for actual in classes if actual != cls)
        fn = sum(confusion[cls][pred] for pred in classes if pred != cls)
        metrics[cls] = {
            "precision": round(safe_div(tp, tp + fp), 4),
            "recall": round(safe_div(tp, tp + fn), 4),
            "tp": tp,
            "fp": fp,
            "fn": fn,
        }

    total = len(rows)
    report = {
        "ok": not missing and evaluated > 0,
        "question": args.question,
        "evaluated": evaluated,
        "missing_or_unlabelled_ids": missing,
        "confusion_matrix": {actual: dict(counts) for actual, counts in confusion.items()},
        "per_class": metrics,
        "routing": dict(routed),
        "auto_candidate_coverage": round(safe_div(routed["auto-candidate"], total), 4),
        "escalation_rate": round(safe_div(total - routed["auto-candidate"], total), 4),
        "warning": "This report is incomplete until latency p50/p95, error rate, actual cost, baselines, OOD and shadow incidents are joined.",
    }
    text = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(text, encoding="utf-8")
    print(text)
    return 0 if report["ok"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
