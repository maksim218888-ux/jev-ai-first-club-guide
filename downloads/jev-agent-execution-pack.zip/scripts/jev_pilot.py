#!/usr/bin/env python3
"""Fail-closed Jev pilot runner.

Default mode performs local validation and writes no network traffic. Live mode
requires an owner-authored approval file bound to the exact config and dataset
hashes. The runner never creates accounts, keys, credits, or production changes.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import os
import random
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Iterable

ENDPOINT = "https://api.typesafe.ai/v1/systemone"
PRICE_PER_MILLION_INPUT_TOKENS_USD = 0.042
LIVE_PHRASE = "OWNER_APPROVED_BOUNDED_JEV_TEST"
# Only explicit rate-limit responses are retried. A 5xx/timeout may represent an
# already-processed paid request, so it fails closed instead of risking a duplicate.
RETRYABLE = {429, 529}
SENSITIVE_KEY = re.compile(
    r"(?i)(api[_-]?key|authorization|password|passwd|secret|token|cookie|session|"
    r"ssn|social[_-]?security|card[_-]?number|cvv|medical|diagnosis|patient|phi)"
)
SENSITIVE_VALUE = re.compile(
    r"(?i)(bearer\s+[a-z0-9._-]{8,}|sk-[a-z0-9_-]{12,}|"
    r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b|"
    r"(?<!\d)(?:\+?\d[\d .()\-]{7,}\d)(?!\d)|"
    r"\b\d{3}-\d{2}-\d{4}\b|\b(?:\d[ -]*?){13,19}\b|"
    r"\b(?:\d{1,3}\.){3}\d{1,3}\b)"
)


class StopError(RuntimeError):
    """A fail-closed condition requiring owner action."""


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        item = json.loads(line)
        if not isinstance(item, dict):
            raise StopError(f"dataset line {number}: expected JSON object")
        rows.append(item)
    if not rows:
        raise StopError("dataset is empty")
    return rows


def iter_nodes(value: Any, path: str = "$", depth: int = 0) -> Iterable[tuple[str, Any, int]]:
    yield path, value, depth
    if isinstance(value, dict):
        for key, child in value.items():
            yield from iter_nodes(child, f"{path}.{key}", depth + 1)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from iter_nodes(child, f"{path}[{index}]", depth + 1)


def scan_state(state: Any, allowed_top_level: set[str], forbidden_fields: set[str]) -> list[str]:
    findings: list[str] = []
    # The bounded harness accepts only reviewed object-shaped state. Free-form
    # strings/lists make field allow-listing impossible and therefore fail closed.
    if not isinstance(state, dict):
        findings.append("state must be an object with an explicit top-level allow-list")
        return findings
    if allowed_top_level:
        extra = sorted(set(state) - allowed_top_level)
        if extra:
            findings.append(f"top-level fields not allow-listed: {', '.join(extra)}")
    for path, value, depth in iter_nodes(state):
        if depth > 50:
            findings.append(f"nesting exceeds local safety limit at {path}")
            break
        key = path.rsplit(".", 1)[-1].split("[", 1)[0]
        if key in forbidden_fields or SENSITIVE_KEY.search(key):
            findings.append(f"sensitive/forbidden field at {path}")
        if isinstance(value, str) and SENSITIVE_VALUE.search(value):
            findings.append(f"possible secret or regulated identifier in value at {path}")
        if isinstance(value, float) and not math.isfinite(value):
            findings.append(f"non-finite number at {path}")
    return findings


def validate_question(question_id: str, question: Any) -> list[str]:
    errors: list[str] = []
    if not isinstance(question, dict):
        return [f"question {question_id}: must be an object"]
    qtype = question.get("type")
    if qtype not in {"choice", "score", "noul"}:
        errors.append(f"question {question_id}: unsupported type {qtype!r}; Box requires a separate approved multimodal pilot")
    if not question.get("instructions"):
        errors.append(f"question {question_id}: instructions are required")
    if qtype == "choice":
        criteria = question.get("criteria")
        if not isinstance(criteria, dict) or len(criteria) < 2:
            errors.append(f"question {question_id}: Choice needs at least two criteria")
    if qtype == "score":
        criteria = question.get("criteria")
        if not isinstance(criteria, dict) or len(criteria) < 2:
            errors.append(f"question {question_id}: Score needs an ordered descriptive scale")
    return errors


def validate_config(config: Any) -> list[str]:
    errors: list[str] = []
    if not isinstance(config, dict):
        return ["config must be a JSON object"]
    if config.get("endpoint") != ENDPOINT:
        errors.append(f"endpoint must be exactly {ENDPOINT}")
    model = config.get("model")
    if model != "jev-1.14.0":
        errors.append("model must be pinned to jev-1.14.0; floating aliases are not accepted by this harness")
    if config.get("stage") not in {"offline", "playground", "test-api", "shadow"}:
        errors.append("stage must be offline, playground, test-api, or shadow; this pack cannot enable canary/production")
    if config.get("risk") != "low":
        errors.append("first pilot must be low risk")
    for name in ("max_test_calls", "max_input_tokens_per_call"):
        if not isinstance(config.get(name), int) or config[name] <= 0:
            errors.append(f"{name} must be a positive integer")
    if not isinstance(config.get("max_budget_usd"), (int, float)) or config.get("max_budget_usd", -1) < 0:
        errors.append("max_budget_usd must be non-negative")
    questions = config.get("questions")
    if not isinstance(questions, dict) or not questions:
        errors.append("questions must be a non-empty object")
    else:
        for question_id, question in questions.items():
            errors.extend(validate_question(question_id, question))
    privacy = config.get("privacy")
    if not isinstance(privacy, dict) or not privacy.get("allowed_top_level_fields"):
        errors.append("privacy.allowed_top_level_fields must be a non-empty list")
    routing = config.get("routing")
    if not isinstance(routing, dict):
        errors.append("routing rules are required")
    else:
        for key in ("auto_min_probability", "review_min_probability"):
            value = routing.get(key)
            if not isinstance(value, (int, float)) or not 0 <= value <= 1:
                errors.append(f"routing.{key} must be between 0 and 1")
        if isinstance(routing.get("auto_min_probability"), (int, float)) and isinstance(routing.get("review_min_probability"), (int, float)):
            if routing["review_min_probability"] >= routing["auto_min_probability"]:
                errors.append("review_min_probability must be lower than auto_min_probability")
        companion = routing.get("companion_noul_yes_min")
        if not isinstance(companion, (int, float)) or not 0 <= companion <= 1:
            errors.append("routing.companion_noul_yes_min must be between 0 and 1")
        per_question = routing.get("per_question")
        if not isinstance(per_question, dict) or set(per_question) != set(questions or {}):
            errors.append("routing.per_question must define thresholds for every question ID")
        else:
            for qid, rule in per_question.items():
                if not isinstance(rule, dict):
                    errors.append(f"routing.per_question.{qid} must be an object")
                    continue
                for key in ("auto_min_probability", "review_min_probability"):
                    value = rule.get(key)
                    if not isinstance(value, (int, float)) or not 0 <= value <= 1:
                        errors.append(f"routing.per_question.{qid}.{key} must be between 0 and 1")
                if isinstance(rule.get("auto_min_probability"), (int, float)) and isinstance(rule.get("review_min_probability"), (int, float)):
                    if rule["review_min_probability"] >= rule["auto_min_probability"]:
                        errors.append(f"routing.per_question.{qid}: review threshold must be lower than auto threshold")
    return errors


def build_payload(config: dict[str, Any], state: Any) -> dict[str, Any]:
    return {"model": config["model"], "state": state, "questions": config["questions"]}


def conservative_token_estimate(payload: dict[str, Any]) -> int:
    # This is deliberately conservative for mixed-language JSON. It is a budget guard,
    # not a tokenizer or a claim about vendor billing.
    return math.ceil(len(canonical_bytes(payload)) / 2)


def route_answer(answer: dict[str, Any], routing: dict[str, Any], question_id: str | None = None) -> str:
    qtype = answer.get("type")
    if qtype == "noul":
        p = answer.get("probability")
    elif qtype in {"choice", "score"}:
        probabilities = answer.get("probabilities") or {}
        selected = answer.get("choice") if qtype == "choice" else str(answer.get("score"))
        p = probabilities.get(selected)
        if p is None and probabilities:
            p = max(probabilities.values())
    else:
        return "human"
    if not isinstance(p, (int, float)):
        return "human"
    thresholds = routing.get("per_question", {}).get(question_id, routing)
    if p >= thresholds["auto_min_probability"]:
        return "auto-candidate"
    if p >= thresholds["review_min_probability"]:
        return "strong-model-or-human"
    return "human"


def validate_and_route_response(response: Any, config: dict[str, Any]) -> dict[str, Any]:
    """Validate exact response shape and apply per-question + companion gates."""
    if not isinstance(response, dict):
        raise StopError("response must be an object")
    if response.get("model") != config["model"]:
        raise StopError("response model differs from pinned model")
    answers = response.get("answers")
    if not isinstance(answers, dict):
        raise StopError("response answers must be an object")
    expected = set(config["questions"])
    if set(answers) != expected:
        raise StopError("response question IDs do not exactly match config")
    routes: dict[str, str] = {}
    for qid, qcfg in config["questions"].items():
        answer = answers[qid]
        if not isinstance(answer, dict) or answer.get("type") != qcfg.get("type"):
            raise StopError(f"response type mismatch for {qid}")
        routes[qid] = route_answer(answer, config["routing"], qid)

    companion_id = config["routing"].get("companion_question_id")
    primary_id = config["routing"].get("primary_question_id")
    final_route = routes.get(primary_id, "human")
    if companion_id:
        companion = answers.get(companion_id, {})
        probability = companion.get("probability") if isinstance(companion, dict) else None
        if not isinstance(probability, (int, float)) or probability < config["routing"]["companion_noul_yes_min"]:
            final_route = "human"
    return {"answers": answers, "routes": routes, "final_route": final_route}


def verify_approval(approval: dict[str, Any], config: dict[str, Any], rows: list[dict[str, Any]], config_hash: str, dataset_hash: str) -> None:
    required = {
        "approval_phrase": LIVE_PHRASE,
        "config_sha256": config_hash,
        "dataset_sha256": dataset_hash,
        "endpoint": ENDPOINT,
        "model": config["model"],
        "data_class": "deidentified-low-risk",
    }
    for key, expected in required.items():
        if approval.get(key) != expected:
            raise StopError(f"approval mismatch: {key}")
    if approval.get("approved_calls") != config["max_test_calls"]:
        raise StopError("approval approved_calls must exactly equal the hard network-attempt cap")
    if len(rows) > approval["approved_calls"]:
        raise StopError("selected rows exceed approved network-attempt cap")
    expires = approval.get("expires_at_utc")
    try:
        expiry = dt.datetime.fromisoformat(expires.replace("Z", "+00:00"))
    except Exception as exc:
        raise StopError("approval expires_at_utc must be ISO-8601") from exc
    if expiry <= dt.datetime.now(dt.timezone.utc):
        raise StopError("approval has expired")
    if approval.get("allow_production") is not False or approval.get("allow_sensitive_data") is not False:
        raise StopError("approval must explicitly deny production and sensitive data")


def request_once(payload: dict[str, Any], api_key: str, timeout: int) -> dict[str, Any]:
    request = urllib.request.Request(
        ENDPOINT,
        data=canonical_bytes(payload),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.load(response)


def request_with_bounded_retry(payload: dict[str, Any], api_key: str, timeout: int, attempts: int = 3) -> tuple[dict[str, Any], int]:
    if attempts <= 0:
        raise StopError("hard network-attempt cap reached before request")
    for attempt in range(1, attempts + 1):
        try:
            return request_once(payload, api_key, timeout), attempt
        except urllib.error.HTTPError as exc:
            if exc.code not in RETRYABLE or attempt == attempts:
                raise StopError(f"HTTP {exc.code}; fail closed, no credential/payment action") from exc
            retry_after = exc.headers.get("Retry-After")
            delay = min(float(retry_after), 8.0) if retry_after and retry_after.replace(".", "", 1).isdigit() else min(2 ** (attempt - 1) + random.random(), 8.0)
            time.sleep(delay)
        except (urllib.error.URLError, TimeoutError) as exc:
            # Ambiguous network failures are not retried automatically: the server may
            # have processed the request. This prevents accidental duplicate calls.
            raise StopError("network outcome is ambiguous; do not retry until owner reviews usage") from exc
    raise StopError("unreachable")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--dataset", required=True, type=Path)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--approval", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()

    if args.dry_run and args.live:
        raise StopError("choose dry-run or live, not both")
    config = load_json(args.config)
    rows = load_jsonl(args.dataset)
    if args.limit is not None:
        if args.limit <= 0:
            raise StopError("limit must be positive")
        rows = rows[: args.limit]
    errors = validate_config(config)
    if errors:
        raise StopError("invalid config: " + "; ".join(errors))
    if len(rows) > config["max_test_calls"]:
        raise StopError("selected rows exceed hard max_test_calls before any request")

    allowed = set(config["privacy"]["allowed_top_level_fields"])
    forbidden = set(config["privacy"].get("forbidden_fields", []))
    previews: list[dict[str, Any]] = []
    total_estimated_tokens = 0
    for row in rows:
        if "id" not in row or "state" not in row:
            raise StopError("every dataset row needs id and state")
        findings = scan_state(row["state"], allowed, forbidden)
        if findings:
            raise StopError(f"privacy preflight failed for {row.get('id')}: " + "; ".join(findings))
        payload = build_payload(config, row["state"])
        estimate = conservative_token_estimate(payload)
        if estimate > config["max_input_tokens_per_call"]:
            raise StopError(f"row {row['id']} exceeds max_input_tokens_per_call")
        total_estimated_tokens += estimate
        previews.append({"id": row["id"], "payload_sha256": sha256_bytes(canonical_bytes(payload)), "estimated_input_tokens_upper_guard": estimate})

    estimated_cost = total_estimated_tokens / 1_000_000 * PRICE_PER_MILLION_INPUT_TOKENS_USD
    if estimated_cost > config["max_budget_usd"]:
        raise StopError("conservative preflight estimate exceeds budget")

    config_hash = sha256_bytes(canonical_bytes(config))
    dataset_hash = sha256_bytes(args.dataset.read_bytes())
    summary: dict[str, Any] = {
        "ok": True,
        "mode": "dry-run" if not args.live else "live-test",
        "endpoint": ENDPOINT,
        "model": config["model"],
        "stage": config["stage"],
        "config_sha256": config_hash,
        "dataset_sha256": dataset_hash,
        "selected_calls": len(rows),
        "hard_network_attempt_cap": config["max_test_calls"],
        "estimated_input_tokens_upper_guard": total_estimated_tokens,
        "estimated_api_cost_upper_guard_usd": round(estimated_cost, 8),
        "payloads": previews,
        "stop_before": ["account", "api-key creation/view", "payment/auto-reload", "sensitive data", "long-context/images", "production/canary", "destructive/public action"],
    }

    if not args.live:
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return 0

    if args.approval is None:
        raise StopError("live mode requires --approval")
    approval = load_json(args.approval)
    verify_approval(approval, config, rows, config_hash, dataset_hash)
    api_key = os.getenv("TYPESAFE_API_KEY")
    if not api_key:
        raise StopError("TYPESAFE_API_KEY is absent; owner must create and store it outside this pack")
    if SENSITIVE_VALUE.search(api_key) is None and len(api_key) < 12:
        raise StopError("TYPESAFE_API_KEY appears malformed; do not print it")

    results: list[dict[str, Any]] = []
    actual_cost = 0.0
    network_attempts = 0
    for call_index, row in enumerate(rows, 1):
        payload = build_payload(config, row["state"])
        estimate = conservative_token_estimate(payload)
        estimated_next_cost = estimate / 1_000_000 * PRICE_PER_MILLION_INPUT_TOKENS_USD
        if actual_cost + estimated_next_cost > config["max_budget_usd"]:
            raise StopError("hard budget guard reached before request")
        attempts_left = config["max_test_calls"] - network_attempts
        response, attempts_used = request_with_bounded_retry(
            payload,
            api_key,
            int(config.get("timeout_seconds", 45)),
            attempts=min(3, attempts_left),
        )
        network_attempts += attempts_used
        usage = response.get("usage") or {}
        input_tokens = usage.get("input_tokens")
        if not isinstance(input_tokens, int) or input_tokens < 0:
            raise StopError("response omitted valid input token usage; budget cannot be enforced")
        actual_cost += input_tokens / 1_000_000 * PRICE_PER_MILLION_INPUT_TOKENS_USD
        if actual_cost > config["max_budget_usd"]:
            raise StopError("actual API cost crossed budget; stop before another call")
        routed = validate_and_route_response(response, config)
        results.append({
            "id": row["id"],
            "call_index": call_index,
            "model": response.get("model"),
            "answers": routed["answers"],
            "routes": routed["routes"],
            "final_route": routed["final_route"],
            "usage": {"input_tokens": input_tokens, "output_tokens": usage.get("output_tokens")},
        })

    summary["actual_api_cost_usd"] = round(actual_cost, 8)
    summary["network_attempts"] = network_attempts
    summary["results"] = results
    output = args.output or Path("jev-live-results.redacted.json")
    output.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"ok": True, "output": str(output), "calls": len(results), "actual_api_cost_usd": round(actual_cost, 8)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except StopError as exc:
        print(f"STOP: {exc}", file=sys.stderr)
        raise SystemExit(2)
