# Official source ledger — checked 2026-11-18

## Product and implementation

1. Docs index: https://docs.typesafe.ai/llms.txt
2. Quick start: https://docs.typesafe.ai/introduction/quickstart
3. Coding agents boundary: https://docs.typesafe.ai/introduction/coding-agents
4. How to build: https://docs.typesafe.ai/concepts/how-to-build-with-system-one
5. Models, price, context, aliases: https://docs.typesafe.ai/models
6. Choice: https://docs.typesafe.ai/primitives/choice
7. Noul: https://docs.typesafe.ai/primitives/noul
8. Confidence: https://docs.typesafe.ai/confidence
9. Companion Noul: https://docs.typesafe.ai/patterns/companion-noul
10. Request rules/errors: https://docs.typesafe.ai/api/errors
11. System One API: https://docs.typesafe.ai/api/system-one
12. Python SDK: https://docs.typesafe.ai/sdk/python
13. Model changelog: https://docs.typesafe.ai/changelog
14. Model jaggedness: https://docs.typesafe.ai/model-jaggedness
15. Agent skill: https://docs.typesafe.ai/agent-skill
16. Official skill repository: https://github.com/typesafe-ai/skills
17. WorkflowEvals: https://github.com/typesafe-ai/WorkflowEvals
18. OpenAPI: https://api.typesafe.ai/openapi.json

## Privacy/legal/region

19. Privacy: https://typesafe.ai/legal/privacy-policy
20. MCA: https://typesafe.ai/legal/mca
21. DPA: https://typesafe.ai/legal/data-processing
22. AUP: https://typesafe.ai/legal/acceptable-use-policy
23. ZDR help article: https://help.typesafe.ai/articles/9520184411-do-you-offer-zdr
24. Training/data use: https://help.typesafe.ai/articles/5940251166-does-typesafe-train-on-my-data
25. BAA/HIPAA: https://help.typesafe.ai/articles/5089157237-do-you-sign-baas-or-support-hipaa
26. DPA/SCC/residency options: https://help.typesafe.ai/articles/9159694888-do-you-offer-a-dpa-baa-scc-and-specific-data-residency-options
27. Bedrock/Vertex/Azure availability: https://help.typesafe.ai/articles/2088283656-is-jev-available-on-amazon-bedrock-google-vertex-ai-or-azure-foundry
28. API key governance: https://help.typesafe.ai/articles/8310295754-who-can-create-and-manage-api-keys
29. Console sign-in options: https://console.typesafe.ai/login
30. Exposed API-key response: https://help.typesafe.ai/articles/5898177504-what-should-i-do-if-my-api-key-is-exposed
31. Independent Jev 1.13 benchmark: https://arxiv.org/html/2609.37647v1
32. LangChain narrow evaluator experiment: https://www.langchain.com/blog/jev-agent-evals-langsmith

## Evidence boundaries

- Vendor benchmark figures remain vendor evidence, not universal performance.
- Account-specific rate limits, credits, payment methods and country availability require owner login/check.
- Public docs do not replace legal/security review for a specific dataset.
- ZDR is request-enabled, not assumed on by default.
- `jev-latest` is movable; pin a version for reproducible eval.
- Independent evidence exists, but it is task- and version-specific. It does not validate vendor headline multipliers universally and adds calibration warnings, especially for multi-label Noul.