# QA checklist

## Problem fit
- [ ] Это быстрое bounded judgment, а не поиск, генерация, точный расчёт или длинный план.
- [ ] Jev только оценивает; side effect выполняет код после gate.
- [ ] Один пилот, один owner, одна основная метрика.

## Evidence
- [ ] Ground truth размечен человеком; synthetic помечен и не используется как доказательство.
- [ ] Tune и frozen final holdout разделены без leakage.
- [ ] Baselines измерены на тех же примерах.
- [ ] Критичные классы имеют отдельные precision/recall/FN/FP.
- [ ] Измерены coverage, escalation rate, abstention, p50/p95, errors и полный cost.
- [ ] OOD, adversarial, multilingual, empty/long и schema edge cases включены.

## Questions and routing
- [ ] Choice criteria взаимно различимы; неполное множество защищено companion Noul.
- [ ] Для Noul используется probability; для Choice — probability выбранного действия.
- [ ] Thresholds выбраны по error cost, не по красивому примеру.
- [ ] Ошибка/timeout/OOD/high risk → fallback/human, никогда silent allow.
- [ ] Pinned model/version записан рядом с questions/thresholds.

## Security/legal/economics
- [ ] Allow-list полей и recursive secret/PII preflight PASS.
- [ ] ZDR/DPA/BAA/residency/retention проверены по нужной категории данных.
- [ ] Ключ только в env/secret manager; отсутствует в Git/ZIP/log/prompt.
- [ ] Budget учитывает Jev, fallback model, human review, engineering, monitoring и incidents.
- [ ] Account/rate limits/payment проверены владельцем после login.

## Rollout/rollback
- [ ] Dry run и unit tests PASS.
- [ ] Shadow mode не совершает внешних действий.
- [ ] Feature flag default OFF; fallback проверен.
- [ ] Rollback owner/RTO/readback определены.
- [ ] Canary/production имеет отдельное письменное одобрение.

Любой незакрытый пункт означает `NO-GO` или продолжение пилота.